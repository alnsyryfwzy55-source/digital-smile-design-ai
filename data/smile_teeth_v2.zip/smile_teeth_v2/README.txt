smile_teeth_v2 - cleaned from the 3 usable sources (all CC BY 4.0; cite them in the report)
Classes: 0 bg, 1..6 = FDI 13,12,11,21,22,23. Native resolution (640 or 224), no resizing.
Cleaning vs v1: per-tooth largest component + hole filling; val/test require all 6 teeth, train >=5;
near-duplicate (dHash) images removed from val/test when similar to any train image (leakage), and
duplicates inside train removed. Source 'lowres' (224px) is train-only; coarse edges.
Counts: train 287 | val 23 | test 20.
Not included: the doctor's photos (no ground-truth masks yet).
